
# coding: utf-8

# ### Visualizing the trained filters

# In[ ]:

# some startup! 
import numpy as np
import matplotlib
# This is needed to save images 
matplotlib.use('Agg')
import matplotlib.pyplot as plt

# Make sure that caffe is on the python path
caffe_root = '/path/to/caffe/'
import sys
sys.path.insert(0, caffe_root + 'python')

# should work if you have made pycaffe
import caffe


# In[ ]:

caffe.set_mode_cpu() # change to gpu if your machine has one 
# when you visualize the 2 layer NN / convnet, make sure to put appropriate paths 
# for the below fields
PRETRAINED = '/path/to/hw1/2_caffe/logreg/logreg-snapshot/_iter_10000.caffemodel'
MODEL = '/path/to/hw1/2_caffe/logreg/deploy.prototxt'

# initialize net
net = caffe.Classifier(MODEL,PRETRAINED)
# you should see caffe initialize! 


# Print the parameters and their shapes (bias is omitted)

# In[ ]:

[(k, v[0].data.shape) for k, v in net.params.items()]
# this will print out all the names and shapes of the trained parameters. In logistic regression 
# it is just one layer 'fc1'


# In[ ]:

# collect all the weights
w = net.params['fc1'][0].data # extract the layer from which you need to visualize
# reshape the parameters to image size
w = w.reshape((10,32,32,3))

# obtain min,max to normalize
w_min, w_max = np.min(w), np.max(w)
# classes
classes = ['plane', 'car', 'bird', 'cat', 'deer', 'dog', 'frog', 'horse', 'ship', 'truck']
# init figure 
fig = plt.figure(figsize=(6,6))
for i in range(10):
    wimg = 255.0*(w[i].squeeze() - w_min) / (w_max - w_min)
    # subplot is (2,5) as ten filters are to be visualized
    fig.add_subplot(2,5,i+1).imshow(wimg.astype('uint8'))
# save fig! 
fig.savefig('logreg/logreg_filt.png')
print 'figure saved'


# In[ ]:

# vis_utils.py has helper code to view multiple filters in single image. Use this to visuzlize 
# neural network adn convnets. 
# import vis_utils
from vis_utils import visualize_grid
# saving the weights is now as simple as:
plt.imsave('logreg/logreg_gridfilt.png',visualize_grid(w, padding=3).astype('uint8'))
# padding is the space between images. Make sure that w is of shape: (N,H,W,C)
print 'figure saved as a grid!'

